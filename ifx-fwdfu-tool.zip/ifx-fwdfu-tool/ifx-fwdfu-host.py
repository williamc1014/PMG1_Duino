# This software is initiated by William Chuang (PSS PCS WCS)
# The license of this implementation is based the requirement of the Infineon
# Reference document: https://www.infineon.com/dgdl/Infineon-AN236282_DFU_MW_ModusToolbox-ApplicationNotes-v02_00-EN.pdf?fileId=8ac78c8c8929aa4d0189f4a839d350b8
# Last update date: August 23th, 2023

import sys
import serial
import serial.tools.list_ports
import time
import argparse
import os
import hashlib
import ctypes
import base64

# The DFU target device USB VID and PID definition
INFINEON_DFU_VID = 0x04B4
INFINEON_DFU_PID = 0xF503

# The application identification number
appIndex = 1
# Start address of the upgraded application image
app_start_address = 0x6000
# End address of the upgraded application image
app_end_address = 0x3FA00
# Row size of PMG1-S3, 256-byte
device_row_size = 0x100
# Flash size of PMG1-S3, 256k-yte
device_flash_size = 0x40000
# Maximum acceptable upgraded image size
device_max_dfu_size = app_end_address - app_start_address

# Buffer of restoring the upgraded image data decoding from the HEX file
flashData = [0] * device_max_dfu_size

# Function: str2Hex
# Input: text type list
# output: integer 
# This function convert the text type hex format string to a integer number and return
# The maximum number is limited to Python 
def str2Hex(text:list) -> int:
    value = 0
    for i in range(len(text)):
        value = value << 4
        if (ord(text[i]) >= ord('0') and ord(text[i]) <= ord('9')):
            value += ord(text[i]) - ord('0')
        elif (ord(text[i]) >= ord('a') and ord(text[i]) <= ord('f')):
            value += ord(text[i]) - ord('a') + 10
        elif (ord(text[i]) >= ord('A') and ord(text[i]) <= ord('F')):
            value += ord(text[i]) - ord('A') + 10

    return value 

# Function: getLineData
# Input: text type string
# output: text type list
# Get each byte elements in a single line and put them into a list
def getLineData(data:str) -> list:
    values = []
    for i in range(0, len(data), 2):
        values.append(str2Hex(data[i:(i+2)]))
    return values

# Function: fillData2Flashbuff
# Input: integer type variable linearAddress indicate the start address of the data to be filled into the buffer
#        integer type list linData contains the data to be filled into the buffer
#        integer type variable numData indicates how many byte to be filled into the buffer
# Output: None
# Put the integer elements into a single linear flash list with the specified address
def fillData2Flashbuff(linearAddress:int, lineData:list, numData:int):
    for i in range(numData):
        flashData[linearAddress+i] = lineData[i]
        
# Function: checkLineValid
# Input: text type string
# Output: boolean, return true if the hex line data is valid, other return false
# Check if the line checksum valid, if it is valid, return true
# The following item will be checked:
# (1) the line should start with a colon character
# (2) the calculated checksum matches the last byte of the line
def checkLineValid (line:str) -> bool:
    checksum = 0
    lineSize = len(line)

    if (line[0] != ':'):
        return False

    # Get the number of the bytes contained in this line, it is located in character 1 ~ 2
    dataSize = str2Hex(line[1:3])

    # calculate the checksum
    # strats from first character, ends to dataSize + 8 (2 for length, 4 for address, 2 for type) in 2 characters steps
    for i in range(1, (dataSize * 2) + 2 + 4 + 2, 2): 
        checksum += str2Hex(line[i:i+2])

    checksum = (~(checksum) + 1) & 0xFF

    # check if the checksum matches the checksum byte in the line
    if (checksum != str2Hex(line[-3:-1])):
        return False
    else:
        return True

# Function: parseInputFile
# Input: text type string, the file name with the full path
# Output: None
# Parse hex file line by line and convert them to a integer list
def parseInputFile (input_file:str):
    segmentAddress = 0
    linearAddress = 0
    numData = 0
    lineType = 0
    lineIdx = 0

    # open the target file, read-only
    rf = open (input_file, 'r', encoding='UTF-8')

    # parse the file line-by-line till the file ends
    for line in rf:
        lineIdx += 1
        # check if the line a valid line, if not, exits the loop
        if (checkLineValid(line) == False):
            break
        # decode the line according to their type
        if (line[7:9] == '00'):
            # Data Type
            lineType = 0
            # data offset address is located in character 3 ~ 6
            linearAddress = str2Hex(line[3:7])
            # calculate the absolute address
            linearAddress += segmentAddress
            # check if the absolute address valid
            if (linearAddress > app_end_address) or (linearAddress < app_start_address):
                print('\nError: Image address excesses application boundary', end=" ", flush=True)
                break
            # get the number of the byte contained in this line, it is located in character 1 ~ 2
            numData = str2Hex(line[1:3])
            # convert the text type line into a integer type list
            lineData = getLineData(line[9:((numData * 2) + 1)+ 9])
            # fill the converted integer list into the buffer
            fillData2Flashbuff(linearAddress - app_start_address, lineData, numData)
        elif (line[7:9] == '01'):
            # EOF record type
            lineType = 1
            break
        elif (line[7:9] == '02'):
            # Extended Segment Address type
            lineType = 2
            # get the base address indicated in character 9 ~ 12 (2-byte)
            segmentAddress = (str2Hex(line[9:13]) * 16)
            linearAddress = 0
        elif (line[7:9] == '03'):
            # Start Segment Address type, ignored and not supported here
            lineType = 3
        elif (line[7:9] == '04'):
            # Extended Linear Address, ignored and not supported here
            lineType = 4
        elif (line[7:9] == '05'):
            # Start Linear Address, ignored and not supported here
            lineType = 5

    # Close the file
    rf.close()
    
# Function: findSerialDevice
# Input: None
# Output: string type com port interface name if a valif Infineon serial device is found, otherwise None
# This file will enumerates the serial interface and find the Infineon DFU device with the specific USB VID/PID
def findSerialDevice():
    comPortIdx = None

    for port in serial.tools.list_ports.comports():
        if port.vid and port.pid is not None:
            sVID = port.vid
            sPID = port.pid
            if sVID == INFINEON_DFU_VID and sPID == INFINEON_DFU_PID:
                comPortIdx = port.name
                break

    return comPortIdx  

# Function: formPackage
# Input: integer type variable command contains to the target DFU device
#        integer type variable length indicates the number of byte in data to be sending to DFU target device
#        integer type list data contains the data body to be sending to DFU target device
# Output: the formed package to be sending to DFU target device
# Form a command package, according to the Infineon DFU middleware requirement
def formPackage(command:int, length:int, data:list) -> list:
    checksum = 0
    package = []
    
    # fill in start of package byte
    package.append(0x01)
    checksum += 0x01
    # fill in the command byte
    package.append((command & 0xFF))
    checksum += (command & 0xFF)
    # fill in the data length (2-byte)
    package.append((length & 0xFF))
    checksum += (length & 0xFF)
    package.append(((length >> 8) & 0xFF))
    checksum += ((length >> 8) & 0xFF)

    # fill in the data
    if (data != None):
        for i in range(len(data)):
            package.append(data[i])
            checksum += data[i]
    
    # fill in the checksum
    checksum = (1 + ~(checksum)) & 0xFFFF
    package.append((checksum & 0xFF))
    package.append(((checksum >> 8) & 0xFF))

    # fill in the end of package byte
    package.append(0x17)

    return package

# Function: enterFlashMode
# Input: None
# Output: boolearn, true if success, otherwise false
# This function perpare the necessary elements of asking target DFU device to enter flash mode.
# The elements are including aommand and parameters, and them from the command package by formPackage.
# And then send the formed package to the target DFU device 
def enterFlashMode() -> bool:
    # Enter Flash Command Code: 0x38
    # Data length: 0x06 (6-byte)
    # Data Body: Silicon ID 
    command = formPackage(0x38, 6, [0x04, 0x03, 0x02, 0x01, 0x00, 0x00])
    print('\nMessage: Entering flash mode', end=" ", flush=True)
    # Send the command to DFU target device
    serPort.write(command)
    # Get the response from DFU target device
    resp = serPort.read(15)
    # if the respond package is not starting with integer 1 (Start of Package) and
    # the response code in the following byte is not success (0x00) then means
    # the command fails
    if (resp[0] != 1) or (resp[1] != 0):
        return False
    else:
        return True

# Function: exitFlashMode
# Input: None
# Output: boolearn, true if success, otherwise false
# This function perpare the necessary elements of asking target DFU device to exit flash mode.
# The elements are including aommand and parameters, and them from the command package by formPackage.
# And then send the formed package to the target DFU device 
def exitFlashMode() -> bool:
    # Enter Flash Command Code: 0x3B
    # Data length: 0
    # Data Body: None
    command = formPackage(0x3B, 0, None)
    print('\nMessage: Exiting flash mode', end=" ", flush=True)
    # Send the command to DFU target device and not expecting to get the result
    serPort.write(command)
    return True

# Function: setMetaData
# Input: None
# Output: boolearn, true if success, otherwise false
# This function perpare the necessary elements of updating metadata to target DFU device.
# The elements are including aommand and parameters, and them from the command package by formPackage.
# And then send the formed package to the target DFU device 
def setMetaData() -> bool:
    # perpare the parameters according the requirement in Infineon DFU middleware
    appSize = device_max_dfu_size
    # target application index (1-byte)
    # application start address (4-byte)
    # application end address (4-byte)
    appParameters = [appIndex & 0xFF, \
                     app_start_address & 0xFF, \
                     app_start_address >> 8 & 0xFF, \
                     app_start_address >> 16 & 0xFF, \
                     app_start_address >> 24 & 0xFF, \
                     (device_max_dfu_size - 4) & 0xFF, \
                     (device_max_dfu_size - 4) >> 8 & 0xFF, \
                     (device_max_dfu_size - 4) >> 16 & 0xFF, \
                     (device_max_dfu_size - 4) >> 24 & 0xFF]
    
    # Command code of writing metadata: 0x4C
    # length of parameter: 9
    # data body: parameters perpared above
    command = formPackage(0x4C, 9, appParameters)
    
    # send the command out
    serPort.write(command)
    # read the response
    resp = serPort.read(7)
    # check if the command executed successfully
    if (resp[0] != 1) or (resp[1] != 0):
        return False
    else:
        return True
    
# Constant: crcTable
# The mash table for calculating checksum in the firmware data body
crcTable = [ \
        0x00000000, 0x105ec76f, 0x20bd8ede, 0x30e349b1,\
        0x417b1dbc, 0x5125dad3, 0x61c69362, 0x7198540d,\
        0x82f63b78, 0x92a8fc17, 0xa24bb5a6, 0xb21572c9,\
        0xc38d26c4, 0xd3d3e1ab, 0xe330a81a, 0xf36e6f75,\
]

# Function: verifyApp
# Input: None
# Output: boolearn, true if application 1 valided, otherwise false
# This function perpare the necessary elements of checking the validity of application 1 in target DFU device.
# The elements are including aommand and parameters, and them from the command package by formPackage.
# And then send the formed package to the target DFU device 
def verifyApp() -> bool:
    # Command code of validating app: 0x31
    # length of parameter: 1
    # data body: the index of application to be checking
    command = formPackage(0x31, 1, [0x01])
    # Send the command out
    serPort.write(command)
    # Get the response
    resp = serPort.read(7)
    # check the respond result
    if (resp[0] != 1) or (resp[1] != 0):
        return False
    else:
        return True

# Function: updateRowChecksum
# Input: integer type list data which contains the data body for checksum calculating
# Output: integer type variable returns the calculated checksum
# This function calculates the checksum of the data sending to DFU target device.
# The calculating is based on the mash table crcTable.
def updateRowChecksum(data:list) -> int:
    checksum = 0xFFFFFFFF
    for i in range(len(data)):
        checksum ^= data[i]
        checksum = (checksum >> 4) ^ crcTable[(checksum & 0xF)]
        checksum = (checksum >> 4) ^ crcTable[(checksum & 0xF)]
    return ~checksum

preDone = 0
curDone = 0
diffDone = 0

# Function: programRow
# Input: integer type varaible idx indicates the row number of the target flash 
#        integer type list data contains the data body to be writing to the target flash
# Output: boolearn, true if application 1 valided, otherwise false
# This function flash the row data into the flash memory of the target DFU device
def programRow(idx:int, data:list) -> bool:
    package = []
    packageChecksum = 0
    rowChecksum = 0xFFFFFFFF

    global preDone
    global curDone
    global diffDone

    # write the row data to target DFU device
    # a row is divided into 32-byte each due to the bulk maximum package size is 64-byte
    for i in range(0, device_row_size, 32):
        # Command code of writing row data: 0x37
        # length: 32-byte
        # data doby: each 32-byte in integer list data
        package = formPackage(0x37, 32, data[i:i+32])
        # send out the package
        serPort.write(package)
        # clear the package for next data writing 
        package.clear()
        # get the response from target DFU device
        resp = serPort.read(7)
        # check if the command executed successfully
        if (resp[0] != 1) or (resp[1] != 0):
            return False
    
    # now all row are writing to the target DFU device 
    # we would get the written data been programmed into the flash memory
    # it is required to attend the CRC checksum of the programming data in the parameter
    # therefor we calculate the CRC checksum first
    rowChecksum = updateRowChecksum(data[0:device_row_size]) & 0xFFFFFFFF

    # perpare the parameters for the flash row programming
    programParameter = []
    # row absolute index
    rowAddress = idx + app_start_address
    # parameters
    # address (aligned to row size), 4-byte
    # checksum of the row data, 4-byte
    programParameter.append((rowAddress & 0xFF))
    programParameter.append(((rowAddress >> 8) & 0xFF))
    programParameter.append(((rowAddress >> 16) & 0xFF))
    programParameter.append(((rowAddress >> 24) & 0xFF))
    programParameter.append((rowChecksum & 0xFF))
    programParameter.append(((rowChecksum >> 8) & 0xFF))
    programParameter.append(((rowChecksum >> 16) & 0xFF))
    programParameter.append(((rowChecksum >> 24) & 0xFF))

    # Command code of programming flash: 0x49
    # length: 8-byte
    # data: parameters perpared above
    package = formPackage(0x49, 8, programParameter)
    # send out the command
    serPort.write(package)
    # get the response
    resp = serPort.read(7)
    # check the command execution result
    if (resp.count != 0):
        if (resp[0] != 1) or (resp[1] != 0):
            return False
    
    curDone = round(idx/device_max_dfu_size*100)
    diffDone = curDone - preDone

    # print out the progress 
    if (diffDone >= 10) :   
        print("\nPage Programmed Done {}%".format(curDone), end=" ", flush=True)
        preDone = curDone
        
    return True

# Function: programFlash
# Input: None
# Output: None
# This function is the main partner function of processing the whole flash DFU proceduce
def programFlash():

    global serPort   
    global preDone
    global curDone
    global diffDone

    preDone = 0
    curDone = 0
    diffDone = 0      

    # Find the Infineon serial port (target DFU device)
    comPortIdx = findSerialDevice()
    # If any Infineon serial device found then setup the serial data format:
    # baudrate 115200, byte-size 8-bit, no parity check, 1-second timeout time
    if (comPortIdx != None):
        serPort = serial.Serial(port=comPortIdx, baudrate=115200, bytesize=8, parity="N", timeout=1)
        
        # Make the target DFU device entering Flash Mode
        if(enterFlashMode() != True):
            serPort.close()
            print("\nError: Fail to enter flash mode", end=" ", flush=True)
            return 
        
        # Set the MetaData
        if (setMetaData() != True):
            serPort.close()
            print('\nError: Fail to setup metadata', end=" ", flush=True)
            return

        # Program the flash row-by-row, except the last row
        for page in range(0, device_max_dfu_size - device_row_size, device_row_size):
            if (programRow(page, flashData[page:(page+device_row_size)]) != True):
                print('\nError: Fail to program page ' + str(page), end=" ", flush=True)
                break
        
        print('\nMessage: Writing app checksum', end=" ", flush=True)

        # we need to specially take care of the flash programming of the last row becuase
        # the last 4-byte of the last row should contain the CRC checksum of the whole application data

        # therefore we calculate the appplication CRC checksum first
        appChecksum = updateRowChecksum(flashData[0:app_end_address - app_start_address - 4]) & 0xFFFFFFFF
        # get the last row data
        lastPage = flashData[(app_end_address-app_start_address-device_row_size):(app_end_address - app_start_address - 4)]
        # fill in the calculated application CRC checksum to the last 4-byte of the last row
        lastPage.append((appChecksum & 0xFF))
        lastPage.append(((appChecksum >> 8) & 0xFF))
        lastPage.append(((appChecksum >> 16) & 0xFF))
        lastPage.append(((appChecksum >> 24) & 0xFF))
        # program the last row
        if (programRow(app_end_address-app_start_address-device_row_size, lastPage) != True):
            print('\nError: Fail to program app checksum page ' + str(page), end=" ", flush=True)

        # valify if the application valid for execution
        if (verifyApp() != True):
            print('\nError: Fail to verify application image', end=" ", flush=True)

        # print out the calculated application checksum
        print('\nApp Checksum: ' + str(hex(appChecksum)), end=" ", flush=True)

        # exits the Flash mode
        exitFlashMode()
        # close the serial port
        serPort.close()
        print('\nDone.', end=" ", flush=True)
    else:
        print('\nError: Cannot find Infineon DFU serial interface', end=" ", flush=True)

# Function: parseArguments
# Input: None
# Output: None
# Handle the command-line input parameters
def parseArguments():
    """ Parse the command line arguments """
    
    parser = argparse.ArgumentParser()

    parser.add_argument ('-i', required=True, help="Input CY HEX File.",
        dest='input_file')

    parser.add_argument('-v', dest='verbose', action='store_true',
            help="optional. Turn ON verbose mode. Default is OFF.")
    parser.add_argument('-q', dest='quiet', action='store_true',
            help="optional. Turn OFF all messages. Default is ON.")

    return parser.parse_args()

    #...

# Main function
# usage: python ifx-fwdfu-hosy.py -i [dfu_target_file_name.hex]
# note: the hex file should be located in the same folder of this python script
if __name__ == "__main__":

    if sys.version_info[0] != 3:
        print ("Invalid Python version. Please use Python 3.x. The script was tested for 3.4.1", end=" ", flush=True);
        exit (1)
   
    #Parse command line arguments
    args = parseArguments()

    if (args.quiet == True):
        args.verbose = False

    filePath = os.path.dirname(os.path.realpath(sys.argv[0]))

    # Check input file
    if (os.path.exists(args.input_file) == False):
        print ("\nERROR: Invalid Input File.", end=" ", flush=True)
        exit (2)

    fileName, fileExtension = os.path.splitext (args.input_file)
    if (fileExtension != '.hex'):
        if args.quiet == False:
            print ("ERROR: Invalid input file format.", end=" ", flush=True)
        exit (2)

    # Parse the input file
    parseInputFile (args.input_file)
    
    programFlash()
       